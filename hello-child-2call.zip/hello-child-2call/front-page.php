<?php
/**
 * 2Call Cuiabá — Landing page (homepage)
 *
 * Template STANDALONE: não chama get_header()/get_footer() do tema pai
 * de propósito, pra evitar conflitos com o markup do Hello Elementor.
 *
 * Title e meta description são injetados pelo functions.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$theme_uri = esc_url( get_stylesheet_directory_uri() );
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php wp_head(); ?>
</head>
<body <?php body_class( 'two-call-landing' ); ?>>

<!-- ============ HEADER ============ -->
<header class="site-header">
  <div class="container header-inner">
    <a class="brand" href="#top" aria-label="2Call Cuiabá">
      <img src="<?php echo $theme_uri; ?>/assets/logo-2call.png" alt="2Call Cuiabá — Se tá na mão, você vê.">
    </a>
    <nav class="nav" aria-label="Navegação principal">
      <a href="#porque">Por que SMS</a>
      <a href="#beneficios">Benefícios</a>
      <a href="#segmentacao">Segmentação</a>
      <a href="#exemplos">Exemplos</a>
      <a href="#orcamento" class="btn btn-red btn-sm cta-text">Faça um orçamento</a>
    </nav>
    <button class="menu-toggle" aria-label="Abrir menu">
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><line x1="4" y1="7" x2="20" y2="7"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="17" x2="20" y2="17"/></svg>
    </button>
  </div>
</header>

<main id="top">

<!-- ============ HERO ============ -->
<section class="hero envelopes">
  <div class="container hero-grid">
    <div class="hero-copy">
      <span class="eyebrow">Se tá na mão, você vê.</span>
      <h1 id="heroHeadline">Mais de <span class="hl">2 milhões</span> de contatos prontos pra receber sua mensagem</h1>
      <p class="hero-sub">SMS marketing em massa em Cuiabá e Várzea Grande. Sua campanha cai direto no bolso de quem importa — sem internet, sem app, sem ser ignorada.</p>
      <div class="hero-cta">
        <a href="#orcamento" class="btn btn-red btn-lg cta-text">Faça um orçamento</a>
        <a href="#porque" class="btn btn-ghost btn-lg">Como funciona</a>
      </div>
      <div class="hero-trust">
        <span class="dot"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg> Base segmentável MT e Brasil</span>
        <span class="dot"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg> 98% de abertura</span>
        <span class="dot"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg> Entrega no mesmo dia</span>
      </div>
    </div>

    <div class="phone-wrap">
      <div class="phone-glow"></div>
      <div class="phone-badge tl">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 2 11 13"/><path d="m22 2-7 20-4-9-9-4 20-7z"/></svg>
        Entrega instantânea
      </div>
      <div class="phone-badge br"><b>98%</b> de abertura</div>
      <div class="phone">
        <div class="phone-notch"></div>
        <div class="phone-screen">
          <div class="sms-bar">
            <div class="sms-ava">2C</div>
            <div class="sms-who"><b>2Call Cuiabá</b><span>● mensagem recebida</span></div>
          </div>
          <div class="sms-thread" id="smsThread">
            <div class="sms-typing"><span></span><span></span><span></span></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ============ POR QUE SMS ============ -->
<section class="section section-cream" id="porque">
  <div class="container">
    <div class="section-head reveal">
      <span class="kicker">Por que SMS?</span>
      <h2 class="h2">O canal mais direto que existe</h2>
      <p class="lead">SMS chega na hora, é barato e não depende de internet nem de aplicativo. Enquanto o e-mail vai pra promoções e o feed soterra sua marca, o SMS cai direto no bolso — e é lido em minutos.</p>
    </div>
    <div class="pitch-grid">
      <div class="stat reveal">
        <div class="num">98%</div>
        <div class="lbl">das mensagens são lidas</div>
        <div class="desc">a grande maioria em até 3 minutos</div>
      </div>
      <div class="stat reveal">
        <div class="num">2 mi+</div>
        <div class="lbl">contatos segmentáveis</div>
        <div class="desc">pessoas e empresas em MT e no Brasil</div>
      </div>
      <div class="stat reveal">
        <div class="num">0</div>
        <div class="lbl">internet necessária</div>
        <div class="desc">não depende de dados, Wi-Fi ou app</div>
      </div>
      <div class="stat reveal">
        <div class="num">160</div>
        <div class="lbl">caracteres no bolso</div>
        <div class="desc">sua marca direto na tela do cliente</div>
      </div>
    </div>
  </div>
</section>

<!-- ============ BENEFÍCIOS ============ -->
<section class="section" id="beneficios">
  <div class="container">
    <div class="section-head reveal">
      <span class="kicker">Benefícios</span>
      <h2 class="h2">Por que sua empresa vai amar o SMS</h2>
      <p class="lead">Um único canal que trabalha o relacionamento, ativa vendas e ainda abre porta com quem nunca te conheceu.</p>
    </div>
    <div class="benefits-grid">
      <div class="benefit reveal">
        <div class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg></div>
        <h3>Engajamento</h3>
        <p>Mensagem que chega e é lida na hora. Taxa de abertura que e-mail e redes sociais não alcançam.</p>
      </div>
      <div class="benefit reveal">
        <div class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="21" x2="14" y1="4" y2="4"/><line x1="10" x2="3" y1="4" y2="4"/><line x1="21" x2="12" y1="12" y2="12"/><line x1="8" x2="3" y1="12" y2="12"/><line x1="21" x2="16" y1="20" y2="20"/><line x1="12" x2="3" y1="20" y2="20"/><line x1="14" x2="14" y1="2" y2="6"/><line x1="8" x2="8" y1="10" y2="14"/><line x1="16" x2="16" y1="18" y2="22"/></svg></div>
        <h3>Personalização</h3>
        <p>Fale com cada cliente pelo nome, com a oferta certa, no momento certo da jornada.</p>
      </div>
      <div class="benefit reveal">
        <div class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z"/><path d="M5 21h14"/></svg></div>
        <h3>Privilégio</h3>
        <p>Quem recebe seu SMS se sente exclusivo. Um canal direto, sem concorrência de feed.</p>
      </div>
      <div class="benefit reveal">
        <div class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg></div>
        <h3>Foco no relacionamento</h3>
        <p>Aniversários, lembretes e novidades. Mantenha sua marca presente o ano inteiro.</p>
      </div>
      <div class="benefit reveal">
        <div class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg></div>
        <h3>Foco nas vendas</h3>
        <p>Promoções, cupons e gatilhos de urgência que convertem em compra na hora.</p>
      </div>
      <div class="benefit reveal">
        <div class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg></div>
        <h3>Foco em prospectos</h3>
        <p>Alcance quem ainda não te conhece com listas segmentadas e prontas pra abordar.</p>
      </div>
    </div>
  </div>
</section>

<!-- ============ SEGMENTAÇÃO ============ -->
<section class="section section-cream envelopes" id="segmentacao">
  <div class="container">
    <div class="section-head center reveal">
      <span class="kicker">Segmentação</span>
      <h2 class="h2">Fale com quem realmente importa</h2>
      <p class="lead" style="margin-inline:auto">Mais de 2 milhões de contatos filtráveis no detalhe. Você escolhe o perfil, a gente entrega a lista certa — pessoas físicas ou empresas.</p>
    </div>
    <div class="seg-grid">
      <div class="seg-card fisica reveal">
        <div class="seg-head">
          <div class="badge"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg></div>
          <div><h3>Pessoas físicas</h3><p>B2C — consumidor final</p></div>
        </div>
        <div class="chips">
          <span class="chip">Faixa etária</span>
          <span class="chip">Sexo</span>
          <span class="chip">Classe social</span>
          <span class="chip">Profissão</span>
          <span class="chip">Operadora</span>
          <span class="chip"><strong>UF</strong></span>
          <span class="chip"><strong>Cidade</strong></span>
          <span class="chip"><strong>Bairro</strong></span>
          <span class="chip"><strong>CEP</strong></span>
          <span class="chip"><strong>DDD</strong></span>
        </div>
        <div class="seg-note"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="10" r="3"/><path d="M12 21.7C17.3 17 20 13 20 10a8 8 0 1 0-16 0c0 3 2.7 7 8 11.7z"/></svg> Filtre por região e perfil até o nível de bairro.</div>
      </div>

      <div class="seg-card juridica reveal">
        <div class="seg-head">
          <div class="badge"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 21h18"/><path d="M5 21V7l8-4v18"/><path d="M19 21V11l-6-4"/><path d="M9 9v.01"/><path d="M9 12v.01"/><path d="M9 15v.01"/><path d="M9 18v.01"/></svg></div>
          <div><h3>Empresas</h3><p>B2B — pessoa jurídica</p></div>
        </div>
        <div class="chips">
          <span class="chip">Ramo de atividade</span>
          <span class="chip">Porte</span>
          <span class="chip"><strong>CNPJ</strong></span>
          <span class="chip">Faturamento</span>
          <span class="chip">Nº de funcionários</span>
          <span class="chip">Região</span>
        </div>
        <div class="seg-note"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg> Encontre empresas pelo perfil exato do seu cliente ideal.</div>
      </div>
    </div>
  </div>
</section>

<!-- ============ EXEMPLOS ============ -->
<section class="section section-petrol" id="exemplos">
  <div class="container">
    <div class="section-head center reveal">
      <span class="kicker">Casos reais</span>
      <h2 class="h2">Mensagens que já saíram daqui</h2>
      <p class="lead" style="margin-inline:auto">Campanhas reais que rodaram pela 2Call para órgãos públicos, varejo e instituições de Mato Grosso.</p>
    </div>
    <div class="examples-grid">
      <div class="ex reveal">
        <div class="ex-top"><div class="ex-ava" style="background:#ea1f28">GMT</div><div class="ex-meta"><b>Governo de MT</b><span>Saúde pública</span></div></div>
        <p>A dengue é uma doença grave. Se apresentar febre, dor de cabeça e dor no corpo, procure uma unidade de saúde. Governo de MT.</p>
        <span class="ex-time">09:21</span>
      </div>
      <div class="ex reveal">
        <div class="ex-top"><div class="ex-ava" style="background:#2f7d3a">IN</div><div class="ex-meta"><b>INDEA / MT</b><span>Agro</span></div></div>
        <p>Produtor rural, vacine seu rebanho bovino e bubalino de 0–24 meses contra aftosa. Vamos manter nosso estado livre desta doença!</p>
        <span class="ex-time">16:19</span>
      </div>
      <div class="ex reveal">
        <div class="ex-top"><div class="ex-ava" style="background:#d4348a">VG</div><div class="ex-meta"><b>VG Shopping</b><span>Varejo</span></div></div>
        <p>Namorados VG Shopping. A cada R$300 em compras ganhe um cupom para concorrer a 2 vales-viagem para Gramado e 1 vale-compras de mil reais.</p>
        <span class="ex-time">20:57</span>
      </div>
      <div class="ex reveal">
        <div class="ex-top"><div class="ex-ava" style="background:#0a66c2">SB</div><div class="ex-meta"><b>SEBRAE</b><span>Capacitação</span></div></div>
        <p>SEBRAE: Hoje, no último dia da Semana do MEI, o tema é Marketing e Vendas. Participe pelo link no SMS.</p>
        <span class="ex-time">08:16</span>
      </div>
      <div class="ex reveal">
        <div class="ex-top"><div class="ex-ava" style="background:#314550">DT</div><div class="ex-meta"><b>Detran / MT</b><span>Serviço público</span></div></div>
        <p>O Governo de Mato Grosso mudou a data de pagamento do IPVA e licenciamento. Acesse detran.com.br e saiba mais.</p>
        <span class="ex-time">10:25</span>
      </div>
      <div class="ex reveal">
        <div class="ex-top"><div class="ex-ava" style="background:#ea1f28">2C</div><div class="ex-meta"><b>Seu negócio aqui</b><span>É a sua vez</span></div></div>
        <p>Sua marca pode estar na tela de milhares de clientes hoje mesmo. Bora montar a sua primeira campanha?</p>
        <span class="ex-time">agora</span>
      </div>
    </div>
  </div>
</section>

<!-- ============ ORÇAMENTO ============ -->
<section class="section form-section envelopes" id="orcamento" style="background:var(--petrol-deep)">
  <div class="container form-grid">
    <div class="form-copy reveal">
      <span class="kicker">Bora começar?</span>
      <h2 class="h2">Faça um orçamento sem compromisso</h2>
      <p class="lead">Conta pra gente quem você quer alcançar. Em poucos minutos a gente responde com o melhor caminho pra sua campanha.</p>
      <ul class="form-list">
        <li><span class="tick"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span> Resposta rápida direto no WhatsApp</li>
        <li><span class="tick"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span> Lista segmentada pro seu público</li>
        <li><span class="tick"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span> Você aprova o texto antes do disparo</li>
        <li><span class="tick"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span> Relatório de entrega após a campanha</li>
      </ul>
    </div>

    <form class="form-card reveal" id="orcamentoForm">
      <h3>Pedir orçamento</h3>
      <p class="fc-sub">Preencha e envie — abrimos o WhatsApp com tudo pronto.</p>
      <div class="field">
        <label for="nome">Seu nome *</label>
        <input id="nome" name="nome" type="text" placeholder="Como podemos te chamar?" required>
      </div>
      <div class="field-row">
        <div class="field">
          <label for="empresa">Empresa</label>
          <input id="empresa" name="empresa" type="text" placeholder="Nome do negócio">
        </div>
        <div class="field">
          <label for="telefone">WhatsApp / Telefone *</label>
          <input id="telefone" name="telefone" type="tel" placeholder="(65) 9 0000-0000" required>
        </div>
      </div>
      <div class="field">
        <label for="tipo">Quero alcançar</label>
        <select id="tipo" name="tipo">
          <option value="Pessoas físicas (B2C)">Pessoas físicas (consumidor)</option>
          <option value="Empresas (B2B)">Empresas (B2B)</option>
          <option value="Ainda não sei, quero orientação">Ainda não sei, me orienta</option>
        </select>
      </div>
      <div class="field">
        <label for="publico">Público-alvo / detalhes da campanha</label>
        <textarea id="publico" name="publico" placeholder="Ex: mulheres de 25–45 anos em Cuiabá e Várzea Grande, para divulgar uma promoção..."></textarea>
      </div>
      <button type="submit" class="btn btn-red btn-lg">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M.057 24l1.687-6.163a11.867 11.867 0 0 1-1.587-5.946C.16 5.335 5.495 0 12.05 0a11.817 11.817 0 0 1 8.413 3.488 11.824 11.824 0 0 1 3.48 8.414c-.003 6.557-5.338 11.892-11.893 11.892a11.9 11.9 0 0 1-5.688-1.448L.057 24zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884a9.86 9.86 0 0 0 1.51 5.26l-.999 3.648 3.978-1.607zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413z"/></svg>
        Pedir no WhatsApp
      </button>
      <p class="form-alt">Prefere e-mail? <a data-mail href="#">junior.lannes@2cmovel.com.br</a></p>
      <p class="form-privacy">Seus dados são usados apenas para preparar seu orçamento. Sem spam.</p>
    </form>
  </div>
</section>

</main>

<!-- ============ FOOTER ============ -->
<footer class="footer">
  <div class="container">
    <div class="footer-grid">
      <div class="footer-brand">
        <img src="<?php echo $theme_uri; ?>/assets/logo-2call.png" alt="2Call Cuiabá">
        <p class="footer-slogan">Se tá na mão, você vê.</p>
        <p>SMS marketing em massa em Cuiabá e Várzea Grande — MT. Mais de 2 milhões de contatos segmentáveis prontos pra impulsionar o seu negócio.</p>
      </div>
      <div>
        <h4>Contato</h4>
        <ul class="footer-list">
          <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg><a data-wa href="#">65 98116-4887</a></li>
          <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 5L2 7"/></svg><a data-mail href="#">junior.lannes@2cmovel.com.br</a></li>
          <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/></svg><span>Rua Mário Motta, 383 — Centro Norte<br>Várzea Grande / MT — CEP 78.110-620</span></li>
        </ul>
      </div>
      <div>
        <h4>Navegação</h4>
        <ul class="footer-list">
          <li><a href="#porque">Por que SMS</a></li>
          <li><a href="#beneficios">Benefícios</a></li>
          <li><a href="#segmentacao">Segmentação</a></li>
          <li><a href="#exemplos">Exemplos reais</a></li>
          <li><a href="#orcamento">Faça um orçamento</a></li>
          <li><a href="<?php echo esc_url( home_url( '/politica-de-privacidade/' ) ); ?>">Política de privacidade</a></li>
          <li><a href="<?php echo esc_url( home_url( '/termos-de-uso/' ) ); ?>">Termos de uso</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© <span id="year">2025</span> 2Call Cuiabá — Todos os direitos reservados.</span>
      <span>SMS marketing em massa · Várzea Grande / MT</span>
    </div>
  </div>
</footer>

<!-- floating whatsapp -->
<a class="fab" data-wa href="#" aria-label="Falar no WhatsApp">
  <svg viewBox="0 0 24 24" fill="currentColor"><path d="M.057 24l1.687-6.163a11.867 11.867 0 0 1-1.587-5.946C.16 5.335 5.495 0 12.05 0a11.817 11.817 0 0 1 8.413 3.488 11.824 11.824 0 0 1 3.48 8.414c-.003 6.557-5.338 11.892-11.893 11.892a11.9 11.9 0 0 1-5.688-1.448L.057 24zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884a9.86 9.86 0 0 0 1.51 5.26l-.999 3.648 3.978-1.607zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413z"/></svg>
</a>

<?php wp_footer(); ?>
</body>
</html>
